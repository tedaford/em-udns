int main() { socket(); connect(); return 0; }
